/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Random;

/**
 *
 * @author Marinho
 */
public class CartoesDTO {
    String numero, codigoSeguranca, dataVencimento, cpf;
    
    float limiteCredito, saldoDevedor;
    
    int minNum, maxNum, minCod, maxCod;

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCodigoSeguranca() {
        return codigoSeguranca;
    }

    public void setCodigoSeguranca(String codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }

    public String getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(String dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public float getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(float limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public float getSaldoDevedor() {
        return saldoDevedor;
    }

    public void setSaldoDevedor(float saldoDevedor) {
        this.saldoDevedor = saldoDevedor;
    }
    
public void dadosDoCartao(){
        minNum = 100000000;
        maxNum = 999999999;
        minCod = 100;
        maxCod = 999;
        
        dataVencimento = "16052025";
        limiteCredito = 1200;
        saldoDevedor = 0;
        
        Random random = new Random();
        
        int numero = random.nextInt((maxNum - minNum) + 1) + minNum;
        String numeroReal = Integer.toString((int) numero);
        setNumero(numeroReal);
        
        int codigo = random.nextInt((maxCod - minCod) + 1) + minCod;
        String codReal = Integer.toString((int) codigo);
        setCodigoSeguranca(codReal);
        
        setDataVencimento(dataVencimento);
        setLimiteCredito(limiteCredito);
        setSaldoDevedor(saldoDevedor);
    }
}
