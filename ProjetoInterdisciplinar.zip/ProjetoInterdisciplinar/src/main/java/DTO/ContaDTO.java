/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Random;

/**
 *
 * @author Marinho
 */
public class ContaDTO {
    String numero, digito, agencia, tipo, saques, cpf, cpfDestinatario, cpfRemetente;
    
    float saldo, limite, valor;
            
    int minConta, maxConta;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSaques() {
        return saques;
    }

    public void setSaques(String saques) {
        this.saques = saques;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDigito() {
        return digito;
    }

    public void setDigito(String digito) {
        this.digito = digito;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getLimite() {
        return limite;
    }

    public void setLimite(float limite) {
        this.limite = limite;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getCpfDestinatario() {
        return cpfDestinatario;
    }

    public void setCpfDestinatario(String cpfDestinatario) {
        this.cpfDestinatario = cpfDestinatario;
    }

    public String getCpfRemetente() {
        return cpfRemetente;
    }

    public void setCpfRemetente(String cpfRemetente) {
        this.cpfRemetente = cpfRemetente;
    }

    public void dadosDaConta(){
        minConta = 100000;
        maxConta = 999999;
        
        tipo = "Conta Corrente";
        agencia = "0001";
        saldo = 1200;
        limite = 2000;
        saques = "6";
        
        Random random = new Random();
        
        int numero = random.nextInt((maxConta - minConta) + 1) + minConta;
        String numeroReal = Integer.toString((int) numero);
        
        int digito = random.nextInt(10);
        String digitoReal = Integer.toString(digito);
        
        setNumero(numeroReal);
        setDigito(digitoReal);
        setAgencia(agencia);
        setTipo(tipo);
        setSaldo(saldo);
        setLimite(limite);
        setSaques(saques);
    }
    
}
