/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author Marinho
 */
public class HistoricoDocTed {
    String cpfRemetente, agenciaRemet, numeroContaRemet, digitoContaRemet, nomeBanco, agencia, numeroConta, digitoConta, cpfDestinatario, data;
    
    float valor;

    public String getCpfRemetente() {
        return cpfRemetente;
    }

    public void setCpfRemetente(String cpfRemetente) {
        this.cpfRemetente = cpfRemetente;
    }

    public String getAgenciaRemet() {
        return agenciaRemet;
    }

    public void setAgenciaRemet(String agenciaRemet) {
        this.agenciaRemet = agenciaRemet;
    }

    public String getNumeroContaRemet() {
        return numeroContaRemet;
    }

    public void setNumeroContaRemet(String numeroContaRemet) {
        this.numeroContaRemet = numeroContaRemet;
    }

    public String getDigitoContaRemet() {
        return digitoContaRemet;
    }

    public void setDigitoContaRemet(String digitoContaRemet) {
        this.digitoContaRemet = digitoContaRemet;
    }

    public String getNomeBanco() {
        return nomeBanco;
    }

    public void setNomeBanco(String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getDigitoConta() {
        return digitoConta;
    }

    public void setDigitoConta(String digitoConta) {
        this.digitoConta = digitoConta;
    }

    public String getCpfDestinatario() {
        return cpfDestinatario;
    }

    public void setCpfDestinatario(String cpfDestinatario) {
        this.cpfDestinatario = cpfDestinatario;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

}
