package DAO;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoDAO {
    public Connection ConectaRepositorio(){
        Connection conn = null;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/repositoriosprojeto","root","12344321");
        }
        catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Conexão" + erro.getMessage());
        }
        return conn;
    }
}
