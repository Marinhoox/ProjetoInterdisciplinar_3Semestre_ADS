package DAO;

import DTO.CartoesDTO;
import DTO.ClienteDTO;
import DTO.ContaDTO;
import DTO.HistoricoDocTed;
import DTO.HistoricoPix;
import VIEW.TelaCadastro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClienteDAO {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<HistoricoPix> listaPix = new ArrayList<>();
    ArrayList<HistoricoDocTed> listaDocTed = new ArrayList<>();
            
    public ResultSet autenticacaoCliente(ClienteDTO objClienteDTO) {
        conn = new ConexaoDAO().ConectaRepositorio();

        try {
            String sql = "select * from Clientes where cpf = ? and senha = ? ";

            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objClienteDTO.getCpf());
            pstm.setString(2, objClienteDTO.getSenha());

            ResultSet rs = pstm.executeQuery();
            
            return rs;

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Cliente: " + erro);
            return null;
        }
    }

    public void CadastrarCliente(ClienteDTO objClienteDTO){
        
        String sql = "insert into clientes (nome, genero, cpf, endereço, telefone, email, senha) "
                + "values (?, ?, ?, ?, ?, ?, ?)";
        
        conn = new ConexaoDAO().ConectaRepositorio();

        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objClienteDTO.getNome());
            pstm.setString(2, objClienteDTO.getGenero());
            pstm.setString(3, objClienteDTO.getCpf());
            pstm.setString(4, objClienteDTO.getEndereco());
            pstm.setString(5, objClienteDTO.getTelefone());
            pstm.setString(6, objClienteDTO.getEmail());
            pstm.setString(7, objClienteDTO.getSenha());
            
            pstm.execute();
            pstm.close();
            
            JOptionPane.showMessageDialog(null, "Cadastro efetuado !");          
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ClienteDAO: " + erro);    
        }
    }
        
    public void CadastrarCartao(CartoesDTO objCartoesDTO){
        objCartoesDTO.dadosDoCartao();
        
        String sql = "insert into cartoes (Numero, codigoSeguranca, dataVencimento, limiteCredito, saldoDevedor, CPF) "
                + "Values (?, ?, ?, ?, ?, ?)";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objCartoesDTO.getNumero());
            pstm.setString(2, objCartoesDTO.getCodigoSeguranca());
            pstm.setString(3, objCartoesDTO.getDataVencimento());
            pstm.setFloat(4, objCartoesDTO.getLimiteCredito());
            pstm.setFloat(5, objCartoesDTO.getSaldoDevedor());
            pstm.setString(6,objCartoesDTO.getCpf());
            
            pstm.execute();
            pstm.close();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "CartãoDAO: " + erro);
        }    
    }
        
    public void cadastrarConta(ContaDTO objContaDTO){
        objContaDTO.dadosDaConta();
        
        String sql = "insert into contas (tipo, agencia, numero, digito, saldo, limite, saques, CPF) "
                + "Values (?, ?, ?, ?, ?, ?, ?, ?)";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objContaDTO.getTipo());
            pstm.setString(2, objContaDTO.getAgencia());
            pstm.setString(3, objContaDTO.getNumero());
            pstm.setString(4, objContaDTO.getDigito());
            pstm.setFloat(5, objContaDTO.getSaldo());
            pstm.setFloat(6, objContaDTO.getLimite());
            pstm.setString(7, objContaDTO.getSaques());
            pstm.setString(8, objContaDTO.getCpf());
            
            pstm.execute();
            pstm.close();

        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "ContaDAO: " + erro);
        }        
    }
    
    public ClienteDTO dadosCliente(ClienteDTO objClienteDTO){
        
        String sql = "select * from clientes where cpf = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objClienteDTO.getCpf());
            
            rs = pstm.executeQuery();
            
            if(rs.next()){
                objClienteDTO.setNome(rs.getString("Nome"));
                objClienteDTO.setGenero(rs.getString("Genero"));
                objClienteDTO.setCpf(rs.getString("CPF"));
                objClienteDTO.setEndereco(rs.getString("Endereço"));
                objClienteDTO.setTelefone(rs.getString("Telefone"));
                objClienteDTO.setEmail(rs.getString("Email"));
            }else{
                return null;
            }
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ClienteDAO: " + erro);
        }  
        return null;
    }
    
    public CartoesDTO dadosCartao(CartoesDTO objCartoesDTO){
        
        String sql = "select * from cartoes where cpf = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objCartoesDTO.getCpf());
            
            rs = pstm.executeQuery();
            
            if(rs.next()){
                objCartoesDTO.setNumero(rs.getString("Numero"));
                objCartoesDTO.setCodigoSeguranca(rs.getString("codigoSeguranca"));
                objCartoesDTO.setDataVencimento(rs.getString("dataVencimento"));
                objCartoesDTO.setCpf(rs.getString("CPF"));
                objCartoesDTO.setLimiteCredito(rs.getFloat("limiteCredito"));
                objCartoesDTO.setSaldoDevedor(rs.getFloat("saldoDevedor"));
            }else{
                return null;
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
        return null;
    }
    
    public ContaDTO dadosConta(ContaDTO objContaDTO){
        
        String sql = "select * from contas where cpf = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objContaDTO.getCpf());
            
            rs = pstm.executeQuery();
            
            if(rs.next()){
                objContaDTO.setNumero(rs.getString("Numero"));
                objContaDTO.setDigito(rs.getString("digito"));
                objContaDTO.setTipo(rs.getString("tipo"));
                objContaDTO.setAgencia(rs.getString("agencia"));
                objContaDTO.setCpf(rs.getString("CPF"));
                objContaDTO.setSaldo(rs.getFloat("saldo"));
                objContaDTO.setLimite(rs.getFloat("limite"));
                objContaDTO.setSaques(rs.getString("saques"));
            }else{
                return null;
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
        return null;
    }
    
    public void transferenciaRetirarPix(ContaDTO objContaDTO){
        
        String sql = "UPDATE contas SET saldo = (saldo - ?) WHERE CPF = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setFloat(1, objContaDTO.getValor());
            pstm.setString(2, objContaDTO.getCpfRemetente());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
        
    }
    
    public void transferenciaAdicionarPix(ContaDTO objContaDTO){
        String sql = "UPDATE contas SET saldo = (saldo + ?) WHERE cpf = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setFloat(1, objContaDTO.getValor());
            pstm.setString(2, objContaDTO.getCpfDestinatario());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
    }
     
    public void adicionarTransferenciaPixHistorico(HistoricoPix objHistoricoPix){
        
        String sql = "insert into transacoes_pix (cpf_remetente, cpf_destinatario, valor, data)"
                + "values (?, ?, ?, ?)";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, objHistoricoPix.getCpfRemetente());
            pstm.setString(2, objHistoricoPix.getCpfDestinatario());
            pstm.setFloat(3, objHistoricoPix.getValor());
            pstm.setString(4, objHistoricoPix.getData());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ClienteDAO: " + erro);
        }
    }
    
    public void transferenciaRetirarDocTed(ContaDTO objContaDTO){
        String sql = "UPDATE contas SET saldo = (saldo - ?) WHERE CPF = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setFloat(1, objContaDTO.getValor());
            pstm.setString(2, objContaDTO.getCpfRemetente());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
    }
    
    public void transferenciaAdicionarDocTed(ContaDTO objContaDTO){
        String sql = "UPDATE contas SET saldo = (saldo + ?) WHERE CPF = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setFloat(1, objContaDTO.getValor());
            pstm.setString(2, objContaDTO.getCpfDestinatario());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
    }
    
    public void adicionarTransferenciaDocTedHistorico(HistoricoDocTed objHistoricoDocTed){
        
        String sql = "insert into transacoes_doc_ted (cpf_remetente, agencia_remet, numeroconta_remet, "
                + "digitoconta_remet, nome_banco, agencia_dest, numero_conta_dest, "
                + "digito_conta_dest, cpf_destinatario, valor, data)"
                + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, objHistoricoDocTed.getCpfRemetente());
            pstm.setString(2, objHistoricoDocTed.getAgenciaRemet());
            pstm.setString(3, objHistoricoDocTed.getNumeroContaRemet());
            pstm.setString(4, objHistoricoDocTed.getDigitoContaRemet());
            pstm.setString(5, objHistoricoDocTed.getNomeBanco());
            pstm.setString(6, objHistoricoDocTed.getAgencia());
            pstm.setString(7, objHistoricoDocTed.getNumeroConta());
            pstm.setString(8, objHistoricoDocTed.getDigitoConta());
            pstm.setString(9, objHistoricoDocTed.getCpfDestinatario());
            pstm.setFloat(10, objHistoricoDocTed.getValor());
            pstm.setString(11, objHistoricoDocTed.getData());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ClienteDAO: " + erro);
        }
    }
    
    public ArrayList<HistoricoPix> carregarHistoricoPix(){
        HistoricoPix objHistoricoPix = new HistoricoPix();
        
        String sql = "select * from transacoes_pix";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);

            rs = pstm.executeQuery();
            
            while(rs.next()){
                objHistoricoPix.setCpfRemetente(rs.getString("cpf_remetente"));
                objHistoricoPix.setCpfDestinatario(rs.getString("cpf_destinatario"));
                objHistoricoPix.setValor(rs.getFloat("valor"));
                objHistoricoPix.setData(rs.getString("data"));
                
                listaPix.add(objHistoricoPix);
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
        
        return listaPix;
    }
    
    public ArrayList<HistoricoDocTed> carregarHistoricoDocTed(){
        HistoricoDocTed objHistoricoDocTed = new HistoricoDocTed();
        
        String sql = "select * from transacoes_doc_ted";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);

            rs = pstm.executeQuery();
            
            while(rs.next()){
                objHistoricoDocTed.setCpfRemetente(rs.getString("cpf_remetente"));
                objHistoricoDocTed.setAgenciaRemet(rs.getString("agencia_remet"));
                objHistoricoDocTed.setNumeroContaRemet(rs.getString("numeroconta_remet"));
                objHistoricoDocTed.setDigitoContaRemet(rs.getString("digitoconta_remet"));
                objHistoricoDocTed.setCpfDestinatario(rs.getString("cpf_destinatario"));
                objHistoricoDocTed.setValor(rs.getFloat("valor"));
                objHistoricoDocTed.setNomeBanco(rs.getString("nome_banco"));
                objHistoricoDocTed.setAgencia(rs.getString("agencia_dest"));
                objHistoricoDocTed.setNumeroConta(rs.getString("numero_conta_dest"));
                objHistoricoDocTed.setDigitoConta(rs.getString("digito_conta_dest"));
                objHistoricoDocTed.setData(rs.getString("data"));
                
                listaDocTed.add(objHistoricoDocTed);
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro);
        }
        
        return listaDocTed;
    }
    
/*        String sql = "select * from transacoes_pix where CPF = ?";
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objHistoricoPix.getCpfRemetente());
            
            rs = pstm.executeQuery();
            if(rs.next()) {
                objHistoricoPix.setCpfRemetente(rs.getString("cpf_remetente"));
                objHistoricoPix.setCpfDestinatario("cpf_destinatario");
                objHistoricoPix.setValor(rs.getFloat("valor"));
            } else {
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null,"ClienteDAO: " + erro); 
        }
        */

    
/*    public ArrayList<ClienteDTO> pesquisarCliente(){
        String sql = "select * from clientes";
        
        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                ClienteDTO objClienteDTO = new ClienteDTO();
                objClienteDTO.setLogin(rs.getString("login"));
                objClienteDTO.setNome(rs.getString("nome"));
                objClienteDTO.setGenero(rs.getString("genero"));
                objClienteDTO.setCpf(rs.getString("cpf"));
                objClienteDTO.setEndereco(rs.getString("Endereço"));
                objClienteDTO.setTelefone(rs.getString("telefone"));
                objClienteDTO.setEmail(rs.getString("email"));
                objClienteDTO.setSenha(rs.getString("senha"));
                
                listaClientes.add(objClienteDTO);
                
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Pesquisa de cliente: " + erro);
        }
        
        return listaClientes;
    }
    
    public void buscaDados(ClienteDTO objClienteDTO, CartoesDTO objCartoesDTO, ContaDTO objContaDTO){
        String sql = "select * from clientes where cpf = ";
        String sqlCt = "select * from cartoes where id_Cartao = "
                + "(select id_cliente from clientes"
        
        conn = new ConexaoDAO().ConectaRepositorio();
        
        try {
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objClienteDTO.getCpf());
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Busca sem sucesso" + erro);
        }
    }*/
}
